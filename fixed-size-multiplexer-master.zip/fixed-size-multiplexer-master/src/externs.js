/**
 * @package Fixed size multiplexer
 * @author  Nazar Mokrynskyi <nazar@mokrynskyi.com>
 * @license 0BSD
 */
/**
 * @param {!Function} wrapper
 */
var define = function (wrapper) {};
var exports = {};
var module = {};
module.exports	= {};
