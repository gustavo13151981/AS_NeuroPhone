/**
 * @package Fixed size multiplexer
 * @author  Nazar Mokrynskyi <nazar@mokrynskyi.com>
 * @license 0BSD
 */
require('build-gc').default('src/index.js', 'src/index.min.js', 'src/externs.js');
