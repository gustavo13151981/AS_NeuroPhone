package models.networking.dtos;

import java.io.Serializable;

/**
 * Created by Esteban Luchsinger on 17.03.2016.
 * DataTransferObject: "Stop" Command
 */
public class StopCommand implements Serializable {
    private static final long serialVersionUID = -776270820315865750L;
}
