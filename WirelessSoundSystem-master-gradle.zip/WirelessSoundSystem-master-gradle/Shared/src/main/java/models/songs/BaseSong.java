package models.songs;

/**
 * <pre>
 * Created by Esteban Luchsinger on 19.04.2016.
 * </pre>
 */
public abstract class BaseSong implements Song {
}
