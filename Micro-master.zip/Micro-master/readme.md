# Micro

## Description

I did this program to test the audio capacity of SDL2.
This software is an oscilloscope for low frequency, microphone, ...  
It can show, the threading, the queue and dequeue, graphism & sound at same time.

## Prerequisite

SDL2_2.0.14  
<https://www.libsdl.org/download-2.0.php>

## Keyboard shortcut

| Key     | Action             |
|---------|--------------------|
| F11     | toggle full screen |
| ESC     | quit               |
