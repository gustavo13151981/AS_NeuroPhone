%       TTECTrA.m
%********************************************************************
% Tool for Turbine Engine Closed-loop Transient Analysis (TTECTrA)
%********************************************************************
% Written by Alicia Zinnecker (N&R Engineering) and Jeffrey Csank (NASA)
% NASA Glenn Research Center, Cleveland, OH
% April 25th, 2013
%
%   Running this file executes the TTECTrA tool to design a set-point
%   controller and transient limiters for an engine model and verify the
%   design through two simulations.
%--------------------------------------------------------------------------
%  REQUIREMENTS:   
%       Maltab(R) control systems toolbox
% *************************************************************************
close all; clear; clc;

% add paths for support and gui functions
addpath('TTECTrA_gui')

load_ans=questdlg('Load saved controller data?','TTECTrA: Load Data?','Yes','No','No');

if strcmp(load_ans,'Yes')         % prompt for data file
    [ttectra_in,dataCHK] = load_ctrl_gui;
    % ask if user wants to re-design part of controller
    dataCHK = redes_ctrl_gui(dataCHK);
    % make sure controller data isn't empty; load default values if it is
    if isempty(ttectra_in)
        ttectra_in=TTECTrA_Inputs;
    end
elseif strcmp(load_ans,'No')
    ttectra_in=TTECTrA_Inputs;      % load input data
    dataCHK = zeros(1,6);       % force all three design steps to run
end

%------------------------------
% Determine setpoint calculator and setpoint controller gains
%------------------------------
if dataCHK(4) == 0      % calculate setpoints
    disp('Calculate Setpoints')
    [SP, in]=TTECTrA_SPcalc_gui(ttectra_in);
    ttectra_in.SP=SP;
    ttectra_in.in=in;
end

if dataCHK(5) == 0      % calculate controller gains
    disp('Find Setpoint Controller Gains')
    ttectra_in=TTECTrA_controller_setup_gui(ttectra_in);
    [output]=TTECTrA_controller(ttectra_in);
    if ~issorted(output.Fdbk)
        [output.Fdbk,idx]=sort(output.Fdbk);
        output.Kp=output.Kp(idx);
        output.Ki=output.Ki(idx);
    end
    ttectra_in.gains=output;
end

%------------------------------
% Setup accel and decel limiters
%------------------------------
if dataCHK(6) == 0
    disp('Calculate Acceleration and Deceleration Limiters')
    lims=TTECTrA_transient_limiter_gui(ttectra_in);
    ttectra_in.Limiter=lims;
    
    %------------------------------
    % Integrate Limiters and Setpoint Controller
    %------------------------------
    ttectra_in.controller.IWUP_gain=TTECTrA_integration(ttectra_in);
    
end

%------------------------------
% Test Controller Design
%------------------------------
% first test the controller design using small throttle transitions (this
% should not cause the limiters to be active)
disp('Setpoint Design Test (small throttle)');

%Determine the min/max thrust and severFigure 7al intermediate points
Rsp=min(ttectra_in.SP.FT_bkpt):(max(ttectra_in.SP.FT_bkpt) - min(ttectra_in.SP.FT_bkpt))/4:max(ttectra_in.SP.FT_bkpt);

ttectra_in.in.t_vec  = [ 0    10    12    22    24    34    36    46    48    58     60    70    72    80];
ttectra_in.in.FT_dmd = [Rsp(1) Rsp(1) Rsp(2) Rsp(2) Rsp(3) Rsp(3) Rsp(4) Rsp(4) Rsp(5) Rsp(5)  Rsp(3) Rsp(3) Rsp(2) Rsp(2)];
ttectra_in.in.loop = 1;

out=simFromTTECTrA(ttectra_in);

if ~isempty(out)
    % create figure to show results
    figure(1);
    subplot(211);
    plot(out.t,out.Fnet,'-',out.t,out.FT_dmd,'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('F_{net}R','FontSize',12);
    legend('actual','command','Location','NorthWest');
    set(gca,'FontSize',12);grid on;
    subplot(212);
    plot(out.t,out.CV_fdbk,'-',out.t,out.CV_dmd,'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('Control variable','FontSize',12);
    set(gca,'FontSize',12);grid on;
    
    figure(3);
    subplot(211);
    plot(out.t,out.HPC_SM,'b-',out.t([1 end]),ttectra_in.Limiter.SMLimit.Accel([1 1]),'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('HPC surge margin (%)','FontSize',12);
    legend('actual','limit','Location','NorthWest');
    set(gca,'FontSize',12);grid on;
    subplot(212);
    plot(out.NcR25,out.Nc_dot,'b.', ...
        ttectra_in.Limiter.HPC_Limiter.NcR25_sched,ttectra_in.Limiter.HPC_Limiter.Ncdot_sched,'r--','LineWidth',2);
    xlabel('Corrected core speed','FontSize',12);
    ylabel('Core acceleration','FontSize',12);
    set(gca,'FontSize',12);grid on;
    
    figure(4);
    subplot(211);
    plot(out.t,out.LPC_SM,'b-',out.t([1 end]),ttectra_in.Limiter.SMLimit.Decel([1 1]),'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('LPC surge margin (%)','FontSize',12);
    legend('actual','limit','Location','NorthWest');
    set(gca,'FontSize',12);grid on;
    subplot(212);
    plot(out.t,out.Wf_vec./out.Ps3,'b-',out.t([1 end]),ttectra_in.Limiter.LPC_Limiter([1 1]),'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('W_f/P_{s3}','FontSize',12);
    set(gca,'FontSize',12);grid on;
    
else
    disp('WARNING -- Simulation failed, no output generated')
end

% then run simulation with large throttle transitions, which should cause
% the limiter to be active for a small amount of time
disp('Limiter Design Test (large throttle)')

% Go from 15% max to max, ensure 15% of max Fnet is greater than idle Fnet
Rlp =[0.15 1.0]*max(ttectra_in.SP.FT_bkpt);
Rlp(1) = max(min(ttectra_in.SP.FT_bkpt),Rlp(1));

ttectra_in.in.t_vec  = [0      10     11     30     32     60];
ttectra_in.in.FT_dmd = [Rlp(1) Rlp(1) Rlp(2) Rlp(2) Rlp(1) Rlp(1)];

out=simFromTTECTrA(ttectra_in);

if ~isempty(out)
    % create figure to show results
    figure(5);
    subplot(211);
    plot(out.t,out.Fnet,'-',out.t,out.FT_dmd,'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('F_{net}R','FontSize',12);
    legend('actual','command','Location','NorthWest');
    set(gca,'FontSize',12);grid on;
    subplot(212);
    plot(out.t,out.CV_fdbk,'-',out.t,out.CV_dmd,'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('Control Variable','FontSize',12);
    set(gca,'FontSize',12);grid on;
    
    figure(7);
    subplot(211);
    plot(out.t,out.HPC_SM,'b-',out.t([1 end]),ttectra_in.Limiter.SMLimit.Accel([1 1]),'r--','LineWidth',2)
    xlabel('time (sec)','FontSize',12);ylabel('HPC surge margin (%)','FontSize',12);
    legend('actual','limit','Location','NorthWest');
    set(gca,'FontSize',12);grid on;
    subplot(212);
    plot(out.NcR25,out.Nc_dot,'b.', ...
        ttectra_in.Limiter.HPC_Limiter.NcR25_sched,ttectra_in.Limiter.HPC_Limiter.Ncdot_sched,'r--','LineWidth',2);
    xlabel('corrected core speed, N_cR_{25}','FontSize',12);
    ylabel('core acceleration, N_{c,dot}','FontSize',12);
    set(gca,'FontSize',12);grid on;
    
    figure(8)
    subplot(211);
    plot(out.t,out.LPC_SM,'b-',out.t([1 end]),ttectra_in.Limiter.SMLimit.Decel([1 1]),'r--','LineWidth',2);
    xlabel('time (sec)','FontSize',12);ylabel('LPC surge margin (%)','FontSize',12);
    legend('actual','limit','Location','NorthWest');
    set(gca,'FontSize',12);grid on;
    subplot(212);
    plot(out.t,out.Wf_vec./out.Ps3,'b-',out.t([1 end]),ttectra_in.Limiter.LPC_Limiter([1 1]),'r--','LineWidth',2);
    xlabel('time (sec)','FontSize',12);ylabel('W_f/P_{s3}','FontSize',12);
    set(gca,'FontSize',12);grid on;
    
    figure(9)
    subplot(2,1,1);
    plot(out.t,out.Fnet,'-',out.t,out.FT_dmd,'r--','LineWidth',2);
    hold on;
    plot([15 15],[min(out.Fnet)*0.96 max(out.Fnet)*1.04],'k-',[0 30],0.98*max(out.Fnet)*[1 1],'c-','Linewidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('F_{net}R','FontSize',12);
    legend('actual','command','Location','SouthEast');
    xlim([8 20])
    set(gca,'FontSize',12);grid on;
    subplot(212);
    plot(out.t,out.CV_fdbk,'-',out.t,out.CV_dmd,'r--','LineWidth',2);
    xlabel('Time (sec)','FontSize',12);ylabel('Control Variable','FontSize',12);
    set(gca,'FontSize',12);grid on;
    xlim([8 20])
    
else
    disp('WARNING -- Simulation failed, no output generated')
end

save_ans=questdlg('Save controller data?','TTECTrA: Save Data?','Yes','No','Yes');

if strcmp(save_ans,'Yes')    % prompt for file name and save
    save_ctrl_gui(ttectra_in);
end