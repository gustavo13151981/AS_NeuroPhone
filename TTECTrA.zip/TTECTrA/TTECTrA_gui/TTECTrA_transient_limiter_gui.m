function output=TTECTrA_transient_limiter_gui(inputs)
%       TTECTrA_transient_limiter.m
%*************************************************************************
% Written by Alicia Zinnecker (N&R Engineering) and Jeffrey Csank (NASA)
% NASA Glenn Research Center, Cleveland, OH
% April 17th, 2013
%
%   This file designs the transient limiters (acceleration and deceleration
%   schedules) for the engine model
%*************************************************************************
close all;

%--------------------------------
% Configure the GUI window
%--------------------------------
S.fh = figure('units','normalized',...
    'position',[.1 .2 .45 .3],...
    'menubar','none',...
    'name','TTECTrA: Transient Limiter Setup',...
    'numbertitle','off',...
    'visible','off',...
    'resize','on');

S.panel1 = uipanel('units','normalized',...
    'pos',[.01 .35 .48 .64],...
    'fontsize',12,...
    'TitlePosition', 'centertop',...
    'Title','Acceleration Limiter');

S.panel2 = uipanel('units','normalized',...
    'pos',[.51 .01 .48 .98],...
    'TitlePosition', 'centertop',...
    'fontsize',12,...
    'Title','Deceleration Limiter');

%------ Acceleration Limiter Panel ------
S.lmtx(1) = uicontrol(S.panel1,...
    'style','text',...
    'unit','normalized',...
    'position',[.01 .80 .5 .16],...
    'HorizontalAlignment','center',...
    'fontsize',9,...
    'String','   Acceleration Minimum Surge Margin (%)');

S.accelSM = uicontrol(S.panel1,...
    'style','edit',...
    'unit','normalized',...
    'position',[0.60 0.75 0.25 0.2],...
    'HorizontalAlignment','left',...
    'fontsize',9,...
    'backgroundcolor','white');

S.setupaccel = uicontrol(S.panel1,...
    'style','push',...
    'unit','normalized',...
    'position',[.05 .1 .4 .4],...
    'fontsize',9,...
    'string','Design Accel Limiter',...
    'enable', 'on',...
    'callback',{@accel_setup_call,S});

S.showaccel = uicontrol(S.panel1,...
    'style','push',...
    'unit','normalized',...
    'position',[.55 .1 .4 .4],...
    'fontsize',9,...
    'string','Show Accel Schedule',...
    'enable', 'off',...
    'callback',{@show_sched_call,S});

%------ Deceleration limiter Panel ------
S.lmtx(1) = uicontrol(S.panel2,...
    'style','text',...
    'unit','normalized',...
    'position',[.01 .80 .5 .13],...
    'HorizontalAlignment','center',... 
    'fontsize',9,....
    'String','    Deceleration Minimum Surge Margin (%)');

S.decelSM = uicontrol(S.panel2,...
    'style','edit',...
    'unit','normalized',...
    'position',[0.60 0.80 0.25 0.13],...
    'HorizontalAlignment','left',...
    'fontsize',9,...
    'backgroundcolor','white');

S.setupdecel = uicontrol(S.panel2,...
    'style','push',...
    'unit','normalized',...
    'position',[.10 .45 .80 .25],...
    'string','Design Decel Limiter',...
    'enable', 'on',...
    'fontsize',9,...
    'callback',{@decel_setup_call,S});

S.decellimitupdate = uipanel(S.panel2,...
    'units','normalized',...
    'pos',[0.1 0.1 0.79 0.27],...
    'TitlePosition', 'centertop',...
    'fontsize',12,...
    'Title', 'Designed Wf/Ps3 Limiter');

S.decellimit = uicontrol(S.decellimitupdate,...
    'style','text',...
    'unit','normalized',...
    'position',[0.1 0.1 0.8 0.6],...
    'string', num2str(0.00,'%1.4e'),...
    'fontsize',12,...
    'HorizontalAlignment','center');

%------ Continue Button ------
S.contBtn = uicontrol(S.fh,...
    'style','push',...
    'unit','normalized',...
    'position',[0.05 0.05 0.4 0.25],...
    'string','Continue',...
    'enable','off',...
    'fontsize',9,...
    'callback',@close_gui_call);

set(S.fh,'closerequestfcn',@close_gui_call)

%--------------------------------------------------------------------------
% Initialize: populate text boxes with pre-defined values when GUI is
%             opened, for any field provided in inputs
%           : load a default acceleration schedule if none is pre-defined
%--------------------------------------------------------------------------
if isfield(inputs,'SMLimit')
    if isfield(inputs.SMLimit,'Accel')
        set(S.accelSM, 'string',num2str(inputs.SMLimit.Accel));
    end
    if isfield(inputs.SMLimit,'Decel')
        set(S.decelSM, 'string', num2str(inputs.SMLimit.Decel));
    end
end

% enable "show" button if acceleration schedule is loaded
% initialize LPC limiter if loaded
% if both are limiters are loaded/initialized, enable the "continue" button
if isfield(inputs,'Limiter')
    initFlag=0;
    if isfield(inputs.Limiter,'HPC_Limiter') && ~isempty(inputs.Limiter.HPC_Limiter.NcR25_sched)
        output.HPC_Limiter.NcR25_sched = inputs.Limiter.HPC_Limiter.NcR25_sched;
        output.HPC_Limiter.Ncdot_sched = inputs.Limiter.HPC_Limiter.Ncdot_sched;
        
        set(S.showaccel,'enable','on');
        initFlag=1;
    else    % assign a default schedule (SLS, 7% minimum SM) if no schedule loaded
        output.SMLimit.Accel = 7;
        output.HPC_Limiter.NcR25_sched = [ 7540 7801.3 8062.7 8324 8585.3 8846.7 9108   9369.3 9630.7 9892   10153 10415  10676  10937 11199 11460 ];
        output.HPC_Limiter.Ncdot_sched = [ 150  150    150    150  750.32 1072.4 1201.4 1279.9 1468.3 1530.9 1880  1625.9 1064.4 150   150   150 ];

        set(S.showaccel,'enable','on');
        initFlag=1;
    end
    
    % create (and hide) figure for plotting acceleration schedule
    f=figure('Name','TTECTrA: Acceleration Schedule','NumberTitle','off');set(f,'visible','off');
    
    if isfield(inputs.Limiter,'LPC_Limiter') && ~isempty(inputs.Limiter.LPC_Limiter)
        output.LPC_Limiter = inputs.Limiter.LPC_Limiter;
        
        set(S.decellimit,'string',num2str(inputs.Limiter.LPC_Limiter));
        initFlag=initFlag+1;
    end
    
    if initFlag==2  % both limiters have been initialized
        set(S.contBtn,'enable','on');
    end
end

%--- move and show the gui
movegui(S.fh,'center');
set(S.fh,'visible','on'); % Make the GUI visible.

uiwait;

%--------------------------------
% Callbacks for user interactions with GUI
%--------------------------------
    function varargout = accel_setup_call(varargin)
        %----------------------------------------------------
        % Callback for finding acceleration schedule
        %----------------------------------------------------
        minSM_des=str2double(get(S.accelSM,'string'));
        output.SMLimit.Accel=minSM_des;
        
        if isempty(output.SMLimit.Accel)
            warndlg({'Enter Acceleration Surge Margin Limit'});
        else        % find acceleration schedule
            set(S.setupaccel,'enable','off');
            set(S.showaccel,'enable','off');
            set(S.setupdecel,'enable','off');
            
            % set idle and take-off fuel flows
            if isfield(inputs,'SP')
                wf_idle=inputs.SP.wf_idle;
                wf_to=inputs.SP.wf_takeoff;
            else    % default values
                wf_idle=0.2;
                wf_to=3.6;
            end
            
            % NcR25 breakpoints for schedule
            xmin= floor((inputs.SP.NcR25_min*.90)/10)*10;
            xmax= round((inputs.SP.NcR25_max*1.1)/10)*10;
            xvec= xmin: (xmax-xmin)/20 : xmax;
            
            % vector of initial fuel flows
            Wf_vec=linspace(wf_idle,wf_to*0.4,8);

            % simulate for transition from each initial thrust to takeoff
            % fuel flow, decreasing transition time until minimum surge
            % margin is below desired value
            
            % flight conditions for all simulations
            temp_in.in.alt=inputs.in.alt;
            temp_in.in.MN=inputs.in.MN;
            temp_in.in.dTamb=inputs.in.dTamb;
            temp_in.in.loop=3;      % open-loop control (fuel-flow command)
            
            NcR25_res=zeros(length(Wf_vec),1);
            Ncdot_res=zeros(length(Wf_vec),1);
            minSM_res=zeros(length(Wf_vec),1);
            
            % run simulations to get acceleration data
            for ctr=1:1:length(Wf_vec)
                display(['Running simulations for Wf0 = ' num2str(Wf_vec(ctr))])
                
                % transition time between idle and takeoff
                if exist('t_tr','var')
                    t_tr=min(10,1.05*t_tr);
                else
                    t_tr=10;
                end
                
                % create fuel-flow command vector for simulation
                temp_in.in.t_vec=[0 10 10+t_tr 25];
                temp_in.in.wf_vec=[Wf_vec([ctr ctr]) wf_to wf_to];
                
                res=simFromTTECTrA(temp_in);   % run initial simulation
                
                if ~isempty(res)    % simulation successful, continue with analysis
                    minSM_res(ctr)=min(res.HPC_SM);     % store minimum SM
                    
                    % resize NcR25 and Ncdot arrays
                    if size(NcR25_res,2)>length(res.NcR25)
                        NcR25_res=NcR25_res(:,1:length(res.NcR25));
                    elseif size(NcR25_res,2)<length(res.NcR25)
                        numrep=ceil(length(res.Nc_dot)/size(Ncdot_res,2));
                        NcR25_res=repmat(NcR25_res,1,numrep);
                    end

                    if size(Ncdot_res,2)>length(res.Nc_dot)
                        Ncdot_res=Ncdot_res(:,1:length(res.Nc_dot));
                    elseif size(Ncdot_res,2)<length(res.Nc_dot);
                        numrep=ceil(length(res.Nc_dot)/size(Ncdot_res,2));
                        Ncdot_res=repmat(Ncdot_res,1,numrep);
                    end
                    
                    NcR25_res(ctr,:)=res.NcR25; % necessary for interp to work
                    
                    % only store accel data (and run subsequent
                    % simulations) if minSM > desired minSM
                    if minSM_res(ctr)>=0.9*minSM_des
                        Ncdot_res(ctr,:)=res.Nc_dot;
                        
                        % decrease t_tr until minSM < desired minSM (OR
                        % until loop counter exceeds prescribed maximum)
                        loop_ctr=1;
                        while min(res.HPC_SM)>=minSM_des && loop_ctr <25
                            t_tr=t_tr*0.80;  % decrease transition time

                            temp_in.in.t_vec=[0 10 10+t_tr 25];

                            res=simFromTTECTrA(temp_in);

                            % overwrite data if SM is still above the desired value
                            if min(res.HPC_SM)>minSM_des
                                NcR25_res(ctr,:)=res.NcR25;
                                Ncdot_res(ctr,:)=res.Nc_dot;
                                minSM_res(ctr)=min(res.HPC_SM);
                            else
                                break;
                            end

                            loop_ctr=loop_ctr+1;
                        end
                    end
                end
            end

            % use interpolation to get acceleration schedule
            minAcc=150;     % fixed minimum acceleration
            
            % curves may have multiple accelerations at the same speed
            % at the repeated speeds, maximum acceleration occur between
            % *last* index of min speed and *first* index of max speed
            idx_s=find(NcR25_res(1,:)==min(NcR25_res(1,:)),1,'last');
            idx_e=find(NcR25_res(1,:)==max(NcR25_res(1,:)),1,'first');

            % interpolate first set of simulation results
            yvec=interp1(NcR25_res(1,idx_s:idx_e),Ncdot_res(1,idx_s:idx_e),xvec);

            % repeat interpolation for each successive set of simulation results
            for i=2:1:length(Wf_vec)
                idx_s=find(NcR25_res(i,:)==min(NcR25_res(i,:)),1,'last');
                idx_e=find(NcR25_res(i,:)==max(NcR25_res(i,:)),1,'first');
                yvec_temp=interp1(NcR25_res(i,idx_s:idx_e),Ncdot_res(i,idx_s:idx_e),xvec);
                yvec=max(yvec,yvec_temp);
            end
            
            yvec=max(yvec,minAcc*ones(1,length(yvec)));   % make sure accel is >= fixed minimum
            
            if sum(yvec) ~= length(yvec)*minAcc      % at least one simulation met minSM > desired minSM
                % shape schedule (increase toward maximum, then decrease)
                idx_t=find(yvec==max(yvec),1,'first');
                for i=2:1:length(yvec)-1
                    if (i<idx_t && yvec(i-1)>yvec(i)) || (i>idx_t && yvec(i)<yvec(i+1))
                        yvec(i)=interp1([xvec(i-1) xvec(i+1)],[yvec(i-1) yvec(i+1)],xvec(i));
                    end
                end
                 
                % assign schedule and enable button to show schedule
                output.HPC_Limiter.NcR25_sched=xvec;
                output.HPC_Limiter.Ncdot_sched=yvec;
                
                set(S.showaccel,'enable','on');
            else                   % no simulations met minSM > desired minSM
                warndlg(sprintf('Minimum surge margin not met -- Default schedule assigned \n Reduce desired surge margin below %2.4f %%',max(minSM_res)));
                
                % assign default schedules
                output.SMLimit.Accel = 7;
                output.HPC_Limiter.NcR25_sched = [ 7540 7801.3 8062.7 8324 8585.3 8846.7 9108   9369.3 9630.7 9892   10153 10415  10676  10937 11199 11460 ];
                output.HPC_Limiter.Ncdot_sched = [ 150  150    150    150  750.32 1072.4 1201.4 1279.9 1468.3 1530.9 1880  1625.9 1064.4 150   150   150 ];

                set(S.showaccel,'enable','on');
            end
             
            % enable buttons for calculating schedules
            set(S.setupaccel,'enable','on');
            set(S.setupdecel,'enable','on');
            
            if isfield(output,'LPC_Limiter') && ~isempty(output.LPC_Limiter)
                set(S.contBtn,'enable','on');
            end
        end
    end

    function varargout = show_sched_call(varargin)
        %----------------------------------------------------
        % Callback to show accelaration schedule
        %----------------------------------------------------
        figure(f);
        plot(output.HPC_Limiter.NcR25_sched,output.HPC_Limiter.Ncdot_sched,'bx-','LineWidth',2,'MarkerSize',6);
        grid on;set(gca,'FontSize',12);
        xlabel('Corrected core speed','FontSize',12);
        ylabel('Core acceleration','FontSize',12);

        if(strncmp(get(S.showaccel,'string'),'Show',4))
            set(f,'visible','on')
            set(S.showaccel,'string','Hide Acceleration Schedule');
        else
            set(f,'visible','off')
            set(S.showaccel,'string','Show Acceleration Schedule');
        end
    end


    function varargout = decel_setup_call(varargin)
        %----------------------------------------------------
        % Callback for finding deceleration limiter
        %----------------------------------------------------
        temp2=str2double(get(S.decelSM,'string'));
        output.SMLimit.Decel=temp2;
        
        if isempty(output.SMLimit.Decel)
            warndlg({'Enter Acceleration Surge Margin Limit'});
        else
            set(S.setupaccel,'enable','off');
            set(S.showaccel,'enable','off');
            set(S.setupdecel,'enable','off');
            
            if isfield(inputs,'SP')
                wf_idle=inputs.SP.wf_idle;
                wf_to=inputs.SP.wf_takeoff;
            else    % default values
                wf_idle=1.0;
                wf_to = 3.6;
            end
            
            % Setup flight condition for decel
            temp_in.in.t_vec=[0 10 10.4 20];
            temp_in.in.wf_vec=[wf_to wf_to wf_idle wf_idle];
            temp_in.in.alt=inputs.in.alt;
            temp_in.in.MN=inputs.in.MN;
            temp_in.in.dTamb=inputs.in.dTamb;
            temp_in.in.loop=3;
            temp_in.controller.FdbkFilterBW=-99;
                        
            watchdog=1;  % initialize watchdog
            i1=1;        % initialize sm counter
            temp_out.LPC_SM=100000;  % force to enter while loop
            
            try
                while min(temp_out.LPC_SM)>= 0.9*output.SMLimit.Decel && watchdog<20;

                    clear temp_out

                    % scale idle Wf if not first time
                    if watchdog>1
                        wf_idle=wf_idle*0.925;
                    end

                    % update Wf input and get data
                    temp_in.in.wf_vec=[3.6 3.6 wf_idle wf_idle];
                    temp_out=simFromTTECTrA(temp_in);     

                    % Determine relationship between Wf/Ps3 and LPC Surge Margin
                    if min(temp_out.LPC_SM) <= output.SMLimit.Decel
                        for i2=2:1:length(temp_out.t)

                            if temp_out.LPC_SM(i2) <= output.SMLimit.Decel && temp_out.LPC_SM(i2)<= temp_out.LPC_SM(i2-1)
                                lpcsm_data(i1,1)= temp_out.Wf_vec(i2)/temp_out.Ps3(i2); %#ok
                                lpcsm_data(i1,2)= temp_out.LPC_SM(i2); %#ok
                                i1=i1+1;
                            end
                        end
                    end                

                    watchdog=watchdog+1;   % increment watchdog
                end
            catch ME
                warndlg({'Error Running Simulations - Increase limit and retry'});
            end
            
            if exist('lpcsm_data','var')
                [~,temp]=min(lpcsm_data(:,2));
                output.LPC_Limiter=lpcsm_data(temp,1);
                set(S.decellimit,'string',num2str(output.LPC_Limiter,'%1.4e'));
            else
                warndlg({'Deceleration Limit Too Low - Could not find solution'});
                set(S.decellimit,'string','NaN');
            end
            
            set(S.setupaccel,'enable','on');
            set(S.setupdecel,'enable','on');
            
            if isfield(output,'HPC_Limiter') && ~isempty(output.HPC_Limiter.Ncdot_sched)
                set(S.showaccel,'enable','on');
                set(S.contBtn,'enable','on');
            end

        end
    end

    function varargout=close_gui_call(src,evnt) %#ok
        %----------------------------------------------------
        % Callback to close window -- warn user and assign NaN if schedules
        % have not been designed
        %----------------------------------------------------
        LIMans=0;HPCans=0;LPCans=0;
        if ~exist('output','var')
            LIMans=questdlg('No limiters have been found.  Do you still want to close the limit calculator window?');
            LIMans=strcmp(LIMans,'Yes');
            output=[];
        elseif ~isfield(output,'HPC_Limiter') || (isempty(output.HPC_Limiter.Ncdot_sched) || isempty(output.HPC_Limiter.NcR25_sched))
            HPCans=questdlg('No acceleration schedule has been assigned.  Do you still want to close the limit calculator window?');
            HPCans=strcmp(HPCans,'Yes');
        elseif ~isfield(output,'LPC_Limiter') || isempty(output.LPC_Limiter)
            LPCans=questdlg('No deceleration limiter has been calculated.  Do you still want to close the limit calculator window?');
            LPCans=strcmp(LPCans,'Yes');
        else
            LIMans=1;
        end

        if ~isfield(output,'SMLimit')   % assign arrays for SM limit if none assigned (avoid errors when plotting sim results, but won't plot a line)
            output.SMLimit.Accel=[NaN NaN];
            output.SMLimit.Decel=[NaN NaN];
        elseif ~isfield(output.SMLimit,'Accel')
            output.SMLimit.Accel=[NaN NaN];
        elseif ~isfield(output.SMLimit,'Decel')
            output.SMLimit.Decel=[NaN NaN];
        end
        
        if LIMans || HPCans || LPCans
            delete(gcf)
        end
    end
end
