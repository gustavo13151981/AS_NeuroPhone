function [ttectra_in] = TTECTrA_Inputs
%       TTECTrA_Inputs.m
%**************************************************************************
% Written by Alicia Zinnecker (N&R Engineering) and Jeffrey Csank (NASA)
% NASA Glenn Research Center
% April 25th, 2013
%
%   This file initializes the variable ttectra_in and any other variables
%   of importance for running the generic control module.  This code allows
%   user settings to be loaded from an external file rather than being
%   hard-coded.
%
%   N.B. Units are only specified where important for TTECTrA to function
%   properly (e.g. bandwidths of filters in the controller).  In cases
%   where units are not specified (e.g. altitude), it is the user's
%   responsibility to ensure the input provided to TTECTrA is in the unites
%   expected by the engine model.
%--------------------------------------------------------------------------
%  REQUIREMENTS:   
%       Maltab(R) control systems toolbox
%**************************************************************************

%---------------------------------------------------------
% Define environmental variables
%---------------------------------------------------------
ttectra_in.in.alt=0;                              % altitude
ttectra_in.in.MN=0;                               % Mach number
ttectra_in.in.dTamb=0;                            % deviation from STD temp
ttectra_in.in.simTime=30;                         % simulation time
ttectra_in.in.simFileName='TTECTrA_example.slx';  % simulation file name 

%---------------------------------------------------------
% Setpoint function setup
%---------------------------------------------------------
ttectra_in.SPcalc.wf_rng=[0.2 3.7]; % fuel flow range
ttectra_in.SPcalc.idle = 2400;      % idle thrust
ttectra_in.SPcalc.takeoff = 40000;  % takeoff thrust
ttectra_in.SPcalc.bkpt=5;           % breakpoints:
%   Scalar = linearly-spaced thrust values [idle takeoff]/[wfmin wfmax]
%   Vector = specific thrust (only) breakpoints
                                                   
%---------------------------------------------------------
% Setpoint controller setup
%---------------------------------------------------------
ttectra_in.controller.LMFileName='LM_PWL.mat';  % file containing linear state space models
ttectra_in.controller.lmVar='LM';       % name of variable containing linear models and breakpoints
ttectra_in.controller.FdbkFilterBW=[];  % BW of feedback filter (Hz) => if filter is used, BW > 0, else BW < 0 or BW = []
ttectra_in.controller.PreFilterBW=2;    % bandwidth of prefilter (Hz)
ttectra_in.controller.CVoutput=1;       % element of model output vector containing control variable (y_i)
ttectra_in.controller.Wfinput=1;        % element of model input vector containing fuel flow command (u_i)
ttectra_in.controller.bandwidth=1.5;    % default controller bandwidth (Hz)
ttectra_in.controller.phasemargin=45;   % default phase margin (degrees)

% specify bandwidth of fuel actuator (Hz)
ttectra_in.actuator.wf_bw=10;

%---------------------------------------------------------
% Transient Limiter setup
%---------------------------------------------------------                           
ttectra_in.SMLimit.Accel=7;     % desired minimum HPC surge margin (%)
ttectra_in.SMLimit.Decel=15;    % desired minimum LPC surge margin (%)

% pre-define acceleration schedules, if known
ttectra_in.Limiter.HPC_Limiter.NcR25_sched=[];
ttectra_in.Limiter.HPC_Limiter.Ncdot_sched=[];
ttectra_in.Limiter.LPC_Limiter=[];                   