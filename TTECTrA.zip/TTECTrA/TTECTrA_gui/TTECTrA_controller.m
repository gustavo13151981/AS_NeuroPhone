function [output] = TTECTrA_controller(inputs)
%       TTECTrA_controller.m
% *************************************************************************
% written by Jeffrey Csank (RHC)
% NASA Glenn Research Center, Cleveland, OH
% March 18, 2013
%
%   This file computes controller gains based on the linear models using a
%   gui and allowing the user to modify the bandwidth and phase margin
%   rather. This file loads the linear model data and creates a transfer
%   function to pass to the gui at each thrust level
% *************************************************************************

% Get the linear model data and store in lmdata
try
    load(inputs.controller.LMFileName);
    lmdata=eval(inputs.controller.lmVar);
    lmfnt=zeros(1,length(lmdata));
    for i=1:1:length(lmdata)
        lmfnt(i)=LM(i).Fn;
    end
    iu=inputs.controller.Wfinput;

    % Ensure that the linear models and thrust points are the same length
    if length(lmdata)==length(lmfnt)
        for ilm=1:1:length(lmdata)
            if isempty(lmdata(ilm).A)
                disp(['WARNING - Empty Matrix for thrust of ' num2str(lmfnt(ilm),'%4.1f')])
            else
                [num,den]=ss2tf(lmdata(ilm).A,lmdata(ilm).B,lmdata(ilm).C,lmdata(ilm).D,iu);

                % set default PI controller tuning goals/requirements
                tempbw=inputs.controller.bandwidth;
                temppm=inputs.controller.phasemargin;
                temppos=inputs.controller.CVoutput;

                if inputs.controller.FdbkFilterBW > 0
                    plant = tf(num(temppos,:),den) * tf([inputs.controller.FdbkFilterBW],[1 inputs.controller.FdbkFilterBW]);
                else
                    plant = tf(num(temppos,:),den);
                end

                % Get controller gains based on plant transfer function
                [output_temp.Kp(ilm), output_temp.Ki(ilm)]=TTECTrA_controllerTune_gui(tempbw, temppm, inputs.controller.PreFilterBW, plant, lmfnt(ilm));
                output_temp.Fdbk(ilm)=lmdata(ilm).IC(temppos);
            end
        end

        % Check outputs and remove points that did not converge
        i2=1;
        for i1=1:1:length(output_temp.Kp)
            if output_temp.Kp(i1)==0 && output_temp.Ki(i1)==0 && output_temp.Fdbk(i1)==0
                % Skip
            elseif i1>1 && output_temp.Fdbk(i1)==output_temp.Fdbk(i1-1)
                % Skip if feedback value is the same as the last point.
            else % If there is data, update output
                output.Kp(i2)=output_temp.Kp(i1);
                output.Ki(i2)=output_temp.Ki(i1);
                output.Fdbk(i2)=output_temp.Fdbk(i1);
                i2=i2+1;
            end
        end
    else
        disp(['WARNING - Entered ' num2str(length(lmdata)) ' Linear models and ' num2str(length(lmfnt)) ' Thrust points'])
        disp(['          The length of the two vectors must match']); %#ok
    end

catch ME
    errordlg(['Error accessing linear model data: ' ME.message]);
end
