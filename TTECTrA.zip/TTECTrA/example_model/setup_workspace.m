%====================
% Alicia Zinnecker
% July 2013
%
% This function sets up the workspace for simulation of the PWL engine
% model.  This setup involves adding the necessary paths and creating a
% workspace variable containing data used by the model.
%
% INPUTS:
%   t_vec = vector of time breakpoints that may be used for control
%           commands
%   wf_0  = initial fuel flow (used to find initial conditions)
% OUTPUT:
%   MWS = workspace variable
%       = structure with the fields:
%           x, u, y    -> arrays of states, inputs, and outputs created
%                         when generating linear models for the PWL model
%           A, B, C, D -> arrays of system matrices for each linear model
%                         comprising the PWL model
%           nfrs -> breakpoints for corrected fan speed at which each
%                   linear model is computed
%           beta -> scaling factor for weights in PWL model
%           mode -> mode for calculating weights in PWL model:
%                      1    -> use exponential weighting
%                      else -> use minimum-distance weighting
%           VSV_sp, VBV_sp -> setpoints for VSV and VBV schedules
%           NfR_sp         -> breakpoints for VSV and VBV schedules
%           C_TSTD, C_PSTD -> standard temperature and pressure (constants)
%           t_vec -> time breakpoints
%           Ts    -> step-size/sampling time of simulation
%           IC    -> initial conditions for x, fuel flow, core speed, P2
%                    and T2
%====================

function MWS = setup_workspace(t_vec,wf_0)

% add paths for mex files and data files
addpath(genpath('example_model'));

% load model data into MWS structure
MWS = load('PWL_mods.mat','x','u','y','A','B','C','D','matrix_axes');
MWS.nfrs = MWS.matrix_axes.nfrs;
MWS = rmfield(MWS,'matrix_axes');

% for model weighting scheme
MWS.beta = 25;
MWS.mode = 1;

% for variable geometry schedules
MWS.VSV_sp = MWS.u(2,1:50:end);
MWS.VBV_sp = MWS.u(3,1:50:end);
MWS.NfR_sp = MWS.x(1,1:50:end);

% define constants (T_STD and P_STD)
MWS.C_TSTD = 518.67;        % degR
MWS.C_PSTD = 14.695951;     % psia

MWS.t_vec  = t_vec;
MWS.Ts = 0.015;

% set initial conditions as closest trim point
dist=1e9;idx=1;
for i=1:1:size(MWS.u,2)
    if abs(MWS.u(1,i) - wf_0) < dist
        dist = abs(MWS.u(1,i) - wf_0);
        idx = i;
    end
end

MWS.IC.x0   = MWS.x(:,idx);
MWS.IC.Wf_0 = MWS.y(10,idx);
MWS.IC.Nc_0 = MWS.y(2,idx);
MWS.IC.P2_0 = MWS.y(6,idx);
MWS.IC.T2_0 = MWS.y(3,idx);