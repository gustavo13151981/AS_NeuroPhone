%====================
% Alicia Zinnecker
% July 2013
%
% Use this function to create the MEX files necessary for running the PWL
% engine model provided for example with the TTECTrA tool.
%====================

mex sfun_weights_C.c -outdir ..
mex sfun_xdot_C.c -outdir ..
mex sfun_output_C.c -outdir ..