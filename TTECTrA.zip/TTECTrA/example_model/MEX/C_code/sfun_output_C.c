/*====================
 * Alicia Zinnecker
 * July 2013
 *
 * This S-function calculates the output vector, y, of the piecewise linear
 * engine model, using the weighting factors provided at the input.  The
 * output is calculated by constructing a weighted linear combination of
 * the models:
 *    dx    <--
 *   ---- =  >   w_i ( C_i (x - x_i) + D_i (u - u_i) + y_i)
 *    dt    <--
 * where x_i, u_i, and y_i are the state, input, and output vectors at each
 * trim point.
 *
 * The states in the model are:
 *    [ Nf Nc Tm_LPC Tm_HPC Tm_burner Tm_HPT Tm_LPT]^T
 * the inputs are:
 *    [ Wf VSV VBV ]^T
 * and the outputs are:
 *    [ Nf Nc T2 T25 T50 P2 Ps3 P50 Fnet Wf VSV VBV EPR T30 P25 tauPX ...
 *      T40 T48 tauLP tauHP 0 LPC_SM HPC_SM Fdrag Fnet Fgross ]^T
 *
 * Dialog Parameters:
 *   nfrs -> corrected fan speed breakpoints for linear models
 *   x_tr -> array containing state trim points from generation of linear
 *           models
 *   u_tr -> array containing input trim points from generation of linear
 *           models
 *   y_tr -> array containing output trim points from generation of linear
 *           models
 *     (x_tr, u_tr, and y_tr may contain more trim points than those used
 *     for the models comprising the PWL engine model)
 *   C    -> array containing output matrices for each linear model
 *   D    -> array containing feedthrough matrices for each linear model
 *     (C = [C_1 C_2 ... C_s] and D = [D_1 D_2 ... D_s], where (*)_i is the
 *     matrix for model i of the PWL engine model)
 * Input Ports:
 *   x -> current state of the system
 *   u -> current input to the system
 *   w -> weighting factors for the linear models
 * Output Port:
 *   y -> output of the model
 * ====================*/


#define S_FUNCTION_NAME  sfun_output_C
#define S_FUNCTION_LEVEL 2
#include "simstruc.h"
#include <math.h>
#include <stdio.h>

/* #defines for dialog parameters (all arrays): nfrs, x_tr, u_tr, y_tr, C, D */
#define s_nfrs(S)             ssGetSFcnParam(S,0)
#define s_x_tr(S)             ssGetSFcnParam(S,1)
#define s_u_tr(S)             ssGetSFcnParam(S,2)
#define s_y_tr(S)             ssGetSFcnParam(S,3)
#define s_C(S)                ssGetSFcnParam(S,4)
#define s_D(S)                ssGetSFcnParam(S,5)
#define NPARAMS 6

/*===================
 * S-Function Methods
 *===================*/

static void mdlInitializeSizes(SimStruct *S) {
    /* See sfuntmp1_doc.c for details on the macros used here */
    int i;
    ssSetNumSFcnParams(S, NPARAMS);     // expected number of parameters
    if(ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return;     // return if number expected != number actual
    }
    
    for (i = 0; i < NPARAMS; i++) {
        ssSetSFcnParamTunable(S, i, 0);    // make nontunable
    }
    
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);
    
    // === SETUP INPUT PORTS ===
    // three inputs: state vector, input vector, weights for models
    if (!ssSetNumInputPorts(S, 3)) return;
    
    // state vector
    ssSetInputPortWidth(S, 0, mxGetM(ssGetSFcnParam(S,1)));
    ssSetInputPortRequiredContiguous(S, 0, true);
    ssSetInputPortDirectFeedThrough(S, 0, 1);
    
    // input vector
    ssSetInputPortWidth(S, 1, mxGetM(ssGetSFcnParam(S,2)));
    ssSetInputPortRequiredContiguous(S, 1, true);
    ssSetInputPortDirectFeedThrough(S, 1, 1);
    
    // vector containing weights for PWL models
    ssSetInputPortWidth(S, 2, mxGetN(ssGetSFcnParam(S,0)));
    ssSetInputPortRequiredContiguous(S, 2, true);
    ssSetInputPortDirectFeedThrough(S, 2, 1);

    // === SETUP OUTPUT PORT ===
    // one output: output vector
    if(!ssSetNumOutputPorts(S, 1)) return;
    
    // output vector
    ssSetOutputPortWidth(S, 0, mxGetM(ssGetSFcnParam(S,3)));

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 0);
    ssSetNumPWork(S, 0);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);
    ssSetOptions(S, 0);
}

static void mdlInitializeSampleTimes(SimStruct *S) {
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

// Determine the outputs of the block: calculate x_dot from weighted combination of LMs
static void mdlOutputs(SimStruct *S, int_T tid) {
    // Get block parameters
    double *nfrs     = mxGetPr(s_nfrs(S));
    double *x_tr_all = mxGetPr(s_x_tr(S));
    double *u_tr_all = mxGetPr(s_u_tr(S));
    double *y_tr_all = mxGetPr(s_y_tr(S));
    double *C_all    = mxGetPr(s_C(S));
    double *D_all    = mxGetPr(s_D(S));
    
    // Define inputs
    const real_T *u1 = (const real_T*) ssGetInputPortSignal(S,0);   // state vector
    const real_T *u2 = (const real_T*) ssGetInputPortSignal(S,1);   // input vector
    const real_T *u3 = (const real_T*) ssGetInputPortSignal(S,2);   // weights
    
    // Allocate output vector
    real_T *y1       = (real_T*) ssGetOutputPortRealSignal(S,0);    // output vector
    
    // For unpacking inputs
    int n = mxGetM(ssGetSFcnParam(S,1));
    int m = mxGetM(ssGetSFcnParam(S,2));
    int p = mxGetM(ssGetSFcnParam(S,3));
    int s = mxGetN(ssGetSFcnParam(S,0));
    int s_tr = mxGetN(ssGetSFcnParam(S,1));
    double x[100],u[100],w[100];
    
    // For packing output
    double y[100];
    
    // other variables
    int idx[100], i, j, k;
    double delta_x, delta_u;
    double x_tr[100][100], u_tr[100][100], y_tr[100][100], C[100][500], D[100][500];

    // find column-indices of x_tr corresponding to the breakpoints nfrs
    for(i = 0; i < s; i++) {
        for(j = 0; j < s_tr; j++) {
            if(x_tr_all[j*n] == nfrs[i]) { idx[i] = j; }
        }
    }

    // create array containing just the trim points
    for(j = 0; j < s; j++) {
        for(i = 0; i < n; i++) { x_tr[i][j] = x_tr_all[idx[j]*n+i]; }
        for(i = 0; i < m; i++) { u_tr[i][j] = u_tr_all[idx[j]*m+i]; }
        for(i = 0; i < p; i++) { y_tr[i][j] = y_tr_all[idx[j]*p+i]; }
    }
    
    // create arrays containing the C and D matrix elements
    for(i = 0; i < p; i++) {
        for(j = 0; j < n*s; j++) { C[i][j] = C_all[j*p+i]; }
        for(j = 0; j < m*s; j++) { D[i][j] = D_all[j*p+i]; }
    }
    
    // Unpack inputs
    for(i = 0; i < n; i++) { x[i] = u1[i]; }
    
    for(i = 0; i < m; i++) { u[i] = u2[i]; }
    
    for(i = 0; i < s; i++) { w[i] = u3[i]; }
    
    // calcualte y as a weighted sum of the linearized model outputs
    for(i = 0; i < p; i++) {
        y[i] = 0;
        for (j = 0; j < s; j++) {
            y[i] = y[i] + w[j]*y_tr[i][j];  // Add weighted trim output
            
            for(k = 0; k < n; k++) {    // Add state contribution
                delta_x = x[k] - x_tr[k][j];
                y[i] = y[i] + w[j]*C[i][j*n+k]*delta_x;
            }
            
            for(k = 0; k < m; k++) {    // Add feedthrough contribution
                delta_u = u[k] - u_tr[k][j];
                y[i] = y[i] + w[j]*D[i][j*m+k]*delta_u;
            }
        }
    }
    
    // Pack outputs
    for(i = 0; i < p; i++) { y1[i] = y[i]; }
}

// At end of simulation, do nothing
static void mdlTerminate(SimStruct *S) {

}

#ifdef MATLAB_MEX_FILE  // Is this file being compiled as a MEX-file?
#include "simulink.c"   // MAX-fil interface mechanism
#else
#include "cg_sfun.h"    // Code generation registration function
#endif
