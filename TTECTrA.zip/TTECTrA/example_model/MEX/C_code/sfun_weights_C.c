/*====================
 * Alicia Zinnecker
 * July 2013
 *
 * This S-function calculates the weights applied to each linear model used
 * to construct the piecewise-linear engine model.  Depending on the "mode"
 * input, it will use one of two methods to find these weights:
 *   (1) Exponential weighting
 *       Calculate the weights based on the distance from the current state
 *       of the system to each trim point using an exponential formula
 *          w_i = exp(-beta*d_i/m), where m = min(d_i)
 *   (2) Closest-model weighting
 *       Use the model constructed for the trim point closest to the
 *       current state of the system
 *                { 1  if i=k, where k is index of closest trim point
 *          w_i = {
 *                { 0  otherwise
 *
 * Dialog Parameters:
 *   beta -> scaling factor for exponential weighting (should be > 0)
 *   mode -> determines method used for calculating weights: 1 for
 *           exponential weighting, otherwise closest-model weighting
 *   nfrs -> corrected fan speed breakpoints for linear models
 *   x_tr -> array containing state trim points from generation of linear
 *           models
 *           (may contain more trim points than those used for the models
 *           comprising the PWL engine model)
 * Input Ports:
 *   x -> current state of the system
 * Output Port:
 *   w -> weighting factors
 * ====================*/

#define S_FUNCTION_NAME  sfun_weights_C
#define S_FUNCTION_LEVEL 2
#include "simstruc.h"
#include <math.h>
#include <stdio.h>

/* #defines for dialog parameters: beta, mode, nfrs (array), x_tr (array) */
#define s_beta(S)             ssGetSFcnParam(S,0)
#define s_mode(S)             ssGetSFcnParam(S,1)
#define s_nfrs(S)             ssGetSFcnParam(S,2)
#define s_x_tr(S)             ssGetSFcnParam(S,3)
#define NPARAMS 4

/*===================
 * S-Function Methods
 *===================*/

static void mdlInitializeSizes(SimStruct *S) {
    /* See sfuntmp1_doc.c for details on the macros used here */
    int i;
    ssSetNumSFcnParams(S, NPARAMS);     // expected number of parameters
    if(ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return;     // return if number expected != number actual
    }
    
    for (i = 0; i < NPARAMS; i++) {
        ssSetSFcnParamTunable(S, i, 0);    // make nontunable
    }
    
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);
    
    // === SETUP INPUT PORTS ===
    // one input: state vector
    if (!ssSetNumInputPorts(S, 1)) return;
    
    // state vector
    ssSetInputPortWidth(S, 0, mxGetM(ssGetSFcnParam(S,3)));
    ssSetInputPortRequiredContiguous(S, 0, true);
    ssSetInputPortDirectFeedThrough(S, 0, 1);
    
    // === SETUP OUTPUT PORT ===
    // one output: vector of weights
    if(!ssSetNumOutputPorts(S, 1)) return;
    
    // vector of weights
    ssSetOutputPortWidth(S, 0, mxGetN(ssGetSFcnParam(S,2)));

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 0);
    ssSetNumPWork(S, 0);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);
    ssSetOptions(S, 0);
}

static void mdlInitializeSampleTimes(SimStruct *S) {
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

// Determine the outputs of the block: calculate wights for the LMs
static void mdlOutputs(SimStruct *S, int_T tid) {
    // Get block parameters
    double beta = *mxGetPr(s_beta(S));
    double mode = *mxGetPr(s_mode(S));
    double *nfrs = mxGetPr(s_nfrs(S));
    double *x_tr_all = mxGetPr(s_x_tr(S));
    
    // Define input
    const real_T *u1 = (const real_T*) ssGetInputPortSignal(S,0);   // state vector
    
    // Allocate output vector
    real_T *y1       = (real_T*) ssGetOutputPortRealSignal(S,0);    // vector of weights
    
    // For unpacking inputs
    int n = mxGetM(ssGetSFcnParam(S,3));
    int s = mxGetN(ssGetSFcnParam(S,2));
    int s_tr = mxGetN(ssGetSFcnParam(S,3));
    double x[100];
    
    // For packing output
    double w[100];
    
    // other variables
    int idx[100], i, j;
    double dist[100], min_d, min_i, w_sum;
    double x_tr[100][100];
    
    // find column-indices of x_tr corresponding to the breakpoints nfrs
    for(i = 0; i < s; i++) {
        for(j = 0; j < s_tr; j++) {
            if(x_tr_all[j*n] == nfrs[i]) { idx[i] = j; }
        }
    }
    
    // create array containing just the trim points
    for(i = 0; i < n; i++) {
        for(j = 0; j < s; j++) {
            x_tr[i][j] = x_tr_all[idx[j]*n+i];
        }
    }
    
    // Unpack input
    for(i = 0; i < n; i++) { x[i] = u1[i]; }
    
    // calculate distance (two-norm) between x and all linearization points
    // and find the minimum distance (and index)
    min_d = 2^32;min_i=0;
    for(i = 0; i < s; i++) {
        dist[i] = 0;
        for(j = 0; j < n; j++) {
            dist[i] = dist[i] + pow((x_tr[j][i] - x[j]),2);
        }
        dist[i] = sqrt(dist[i]);
        
        if(dist[i] < min_d) {
            min_d = dist[i];
            min_i = i;
        }
    }
    
    // calculate weights
    if(mode == 1) {     // use exponential weighting scheme
        w_sum = 0;
        
        for(i = 0; i < s; i++) {
            w[i] = exp(-beta*dist[i]/min_d);
            w_sum = w_sum + w[i];
        }
        
        // normalize weights w.r.t. S
        for(i = 0; i < s; i++) { w[i] = w[i]/w_sum; }
        
    }
    else {              // use closest-model weighting scheme
        for(i = 0; i < s; i++) {
            if(i == min_i) { w[i] = 1; }
            else { w[i] = 0; }
        }
    }
    
    // Pack outputs
    for(i = 0; i < s; i++) { y1[i] = w[i]; }
}

// At end of simulation, do nothing
static void mdlTerminate(SimStruct *S) {

}

#ifdef MATLAB_MEX_FILE  // Is this file being compiled as a MEX-file?
#include "simulink.c"   // MAX-fil interface mechanism
#else
#include "cg_sfun.h"    // Code generation registration function
#endif
