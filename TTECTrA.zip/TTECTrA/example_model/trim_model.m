%====================
% Alicia Zinnecker
% July 2013
%
% This function finds the initial fuel flow for the PWL engine model at the
% trim condition specified in the input argument through interpolation.
%
% INPUTS:
%   cond   = trim condition (e.g. thrust value)
%   op_idx = index of output vector corresponding to variable represented
%            by cond
% OUTPUT:
%   wf_0   = fuel flow at the trim condition
%====================

function wf_0 = trim_model(cond,op_idx)

% load the linear model data
addpath(genpath('model_data'));
load PWL_mods.mat y

wf_0=interp1(y(op_idx,:),y(10,:),cond,'linear','extrap');