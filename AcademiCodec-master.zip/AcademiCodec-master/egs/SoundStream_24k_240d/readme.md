# The training code of SoundStream


### For Training
set the right path to start.sh

run: `bash start.sh`

### For Inference


模型不开源，这个目录暂未整理
