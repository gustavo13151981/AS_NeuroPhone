# generating-sound-with-neural-networks
Code and slides for the "Generating Sound with Neural Network" series on The Sound of AI Youtube channel.
