from typing import Union, Dict

LabelText = Union[str, Dict[str, str]]
