## Mic-Audio-Checker
### Description
A simple program I made that just checks to see if your mic volume is within 80-100 range.

### - [NAudio (GitHub)](https://github.com/naudio/NAudio)

### How To Use
\*\*\*Video Link Coming Soon\*\*\* (Not An Excuse)

### Download
[MicAudioChecker.zip](https://github.com/sh4d0w4RCH3R415/Mic-Audio-Checker/releases/download/1.0.0/MicAudioChecker.zip)
