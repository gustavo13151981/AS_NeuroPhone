/* Copyright (c) 1998-2007 Kevin Cameron */
/* Distributed under the GNU Lesser General Public License */
#undef  sim_extra_h_rcsid
#define sim_extra_h_rcsid() {return "$Id: sim_extra.h,v 1.3 2007/03/28 07:23:27 dkc Exp $";} /* RCS ID */

 
#define SNS_EXTRA         SNS_SIM_ITEM,
