/* Copyright (c) 1998-2007 Kevin Cameron */
/* Distributed under the GNU Lesser General Public License */
#undef  Xref_h_rcsid
#define Xref_h_rcsid() {return "$Id: Xref.h,v 1.10 2007/03/28 07:22:28 dkc Exp $";} /* RCS ID */

 
// Pool Cross Reference Operators

#undef Ref

