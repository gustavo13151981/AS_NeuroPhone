/* Copyright (c) 1998-2007 Kevin Cameron */
/* Distributed under the GNU Lesser General Public License */
#undef  windows_defs_h_rcsid
#define windows_defs_h_rcsid() {return "$Id: windows_defs.h,v 1.10 2007/03/28 07:23:26 dkc Exp $";} /* RCS ID */

 
#define WINDOWS

#define OS_DIR_SEP  "\\"
#define OS_DIR_SEP2 "/"
#define OS_TYPE_SEP "."
#define OS_CWD      "."
#define OS_ROOT     "$DRIVE:"
#define OS_TMP_EXT  ""
#define SH_LST_SEP  ";"
#define OS_LIB_PRFX "lib"
#define OS_LIB_SHRD ".dll"

#define DEV_NULL    0

