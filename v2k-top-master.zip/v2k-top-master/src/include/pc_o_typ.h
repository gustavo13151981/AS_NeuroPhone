/* Copyright (c) 1998-2007 Kevin Cameron */
/* Distributed under the GNU Lesser General Public License */

#undef  pc_o_typ_h_rcsid
#define pc_o_typ_h_rcsid() {return "$Id: pc_o_typ.h,v 1.1 2009/12/01 20:25:45 dkc Exp $";} /* RCS ID */

PC_OT_DECL(PCO_Null,      "",   "null",      FT_Null)
PC_OT_DECL(PCO_Class,     "cls","class",     FT_Null)

#undef PC_OT_DECL
