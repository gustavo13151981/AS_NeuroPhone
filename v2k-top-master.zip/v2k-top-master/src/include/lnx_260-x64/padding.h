/* Copyright (c) 1998,1999,2001,2002,2003 Kevin Cameron */
/* Distributed under the GNU Lesser General Public License */
#undef  padding_h_rcsid
#define padding_h_rcsid() {return "$id";} /* RCS ID */

